from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class User_notuser(models.Model):
    id= models.AutoField(primary_key=True)
    firstName= models.CharField(max_length=50)
    lastName=models.CharField(max_length=50)
    CreatedAt=models.DateTimeField(auto_now_add=True)
    UpdatedAt=models.DateTimeField(auto_now=True)



class Topic(models.Model):
    name = models.CharField(max_length=200)


    def __str__(self) -> str:
        return self.name

class Room(models.Model):
    host=models.ForeignKey(User,on_delete=models.SET_NULL,null=True)
    topic=models.ForeignKey(Topic,on_delete=models.SET_NULL,null=True)
    name =models.CharField(max_length=50)
    description =models.TextField(blank=True,null=True)
    participant=models.ManyToManyField(User,related_name='participant',blank=True)
    updated =models.DateTimeField(auto_now=True)
    created=models.DateTimeField(auto_now_add=True)

    def __str__(self) :
        return self.name
    
    class Meta:
        ordering=['-updated','-created']
    

class Message(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    room= models.ForeignKey(Room,on_delete=models.CASCADE)
    body=models.TextField()
    updated =models.DateTimeField(auto_now=True)
    created=models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return self.body[0:50]
    class Meta:
        ordering=['-updated','-created']